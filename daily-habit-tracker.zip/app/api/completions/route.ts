import { getCompletionsCollection } from '@/lib/mongodb'
import { ObjectId } from 'mongodb'
import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    const collection = await getCompletionsCollection()
    const completions = await collection.find({}).toArray()

    // Convert to object format for client
    const result: { [key: string]: number[] } = {}
    for (const doc of completions) {
      result[doc.habitId.toString()] = doc.days || []
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error('Error fetching completions:', error)
    return NextResponse.json({ error: 'Failed to fetch completions' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { habitId, day, completed } = body

    if (!habitId || typeof day !== 'number') {
      return NextResponse.json({ error: 'Invalid parameters' }, { status: 400 })
    }

    if (!ObjectId.isValid(habitId)) {
      return NextResponse.json({ error: 'Invalid habit ID' }, { status: 400 })
    }

    const habitIdObj = new ObjectId(habitId)
    const collection = await getCompletionsCollection()

    // Find or create completion record for this habit
    let completion = await collection.findOne({ habitId: habitIdObj })

    if (!completion) {
      // Create new completion record
      await collection.insertOne({
        habitId: habitIdObj,
        days: completed ? [day] : [],
        updatedAt: new Date(),
      })
    } else {
      // Update existing record
      const days = completion.days || []
      if (completed) {
        if (!days.includes(day)) {
          days.push(day)
        }
      } else {
        const index = days.indexOf(day)
        if (index > -1) {
          days.splice(index, 1)
        }
      }

      await collection.updateOne(
        { habitId: habitIdObj },
        {
          $set: {
            days,
            updatedAt: new Date(),
          },
        }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error updating completion:', error)
    return NextResponse.json({ error: 'Failed to update completion' }, { status: 500 })
  }
}
